#include<iostream>

using namespace std;

int main() {
    int a[10];
    int b[10],c,c1,c2,c4,i;

    cout<<"Enter 4 bits of data one by one\n";
    cin>>a[3];
    cin>>a[5];
    cin>>a[6];
    cin>>a[7];

    //Calculation of even parity
    a[1]=a[3]^a[5]^a[7];
	a[2]=a[3]^a[6]^a[7];
	a[4]=a[5]^a[6]^a[7];

	cout<<"\nEncoded data is\n";
	for(i=1;i<8;i++)
        cout<<a[i]<<" ";

	cout<<"\n\nEnter received data bits one by one\n";
    for(i=1;i<8;i++)
        cin>>b[i];

    c1=b[1]^b[3]^b[5]^b[7];
    c2=b[2]^b[3]^b[6]^b[7];
    c4=b[4]^b[5]^b[6]^b[7];
	c=c1*1 + c2*2 + c4*4;

    if(c==0) {
	cout<<"\nNo error while transmission of data\n";
    }
	else {
	cout<<"\nError on position "<<c<<"\n";

	if(b[c]==0){
        b[c]=1;
	}
	else{
       b[c]=0;
	}
	cout<<"Corrected data: ";
	for(i=1;i<8;i++){
        cout<<b[i]<<" ";
	}
	}

	return 0;
}
