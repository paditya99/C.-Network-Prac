#include<iostream>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
using namespace std;
int main(){
  int p,i,a,w,nac,ack;
  cout<<"Enter the packet size: ";
  cin>>a;
  cout<<"Enter the window size: ";
  cin>>w;
  cout<<"\nTransmission begins... Packet size is: "<<a<<endl;
  for(i=1;i<=a;){
    cout<<"\nSending packets from "<<i<<" to "<<w+i-1<<endl;
    for(p=i;p<=w;p++){
      cout<<"\nSENDER'S SIDE:\nTransmitting packet "<<p;
      cout<<"\nRECEIVER'S SIDE:\nAcknowledgement number "<<(p+1)<<" has been sent.\n";
    }
    nac=rand()%w+1;
    if(nac==i){
      cout<<"Ack= "<<w+i;
      i=w+i;
      continue;
    }
    cout<<"\nNEGATIVE ACK received: "<<nac;
    cout<<"\nSENDER'S SIDE:\nSending packet: "<<nac;
    cout<<"\nRECEIVER'S SIDE:\nAcknowledgement number: "<<nac+i<<" has been sent.\n";
    cout<<"\nRECEIVER'S SIDE:\nAcknowledgement number: "<<(i+w)<<" has been sent.\n";
    i=i+w;



  }

}
