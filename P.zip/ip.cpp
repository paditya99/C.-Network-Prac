#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;

char classdefine(string c){
    char a[50];
    int i;
   for(i=0;i<c.length();i++){

        if(c[i]!='.'){
            a[i]=c[i];

        }
        else{
            break;
        }

   }

   int d=atoi(a);
   if(d>=0 && d<=127){
    return 'A';

   }
   if(d>=128 && d<=191){
    return 'B';
   }
   if(d>=192 && d<=223){
    return 'C';
   }
   if(d>=224 && d<=239){
    return 'D';
   }
   if(d>=240 && d<=255){
     return 'E';
   }

}

void iddefine(char s[],char a){
    char network[12], host[12];
    for (int k = 0; k < 12; k++){
       network[k] = host[k] = '\0';
    }



     if(a=='A'){
        int i = 0, j = 0;
        while (s[j] != '.'){
            network[i++] = s[j++];
        }

        i = 0;
        j++;
        while (s[j] != '\0') {
           host[i++] = s[j++];
        }

        cout<<"\nNetwork ID is "<<network;
        cout<<"\nHost ID is "<<host;

   }
   else if(a=='B'){
        int i = 0, j = 0,dotCount = 0;
        while (dotCount < 2)
        {
            network[i++] = s[j++];
            if (s[j] == '.')
                dotCount++;
        }
        i = 0;
        j++;

        while (s[j] != '\0')
            host[i++] = s[j++];

        cout<<"\nNetwork ID is "<<network;
        cout<<"\nHost ID is "<<host;


   }
   else if(a=='C'){

        int i = 0, j = 0,dotCount = 0;
        while (dotCount < 3)
        {
            network[i++] = s[j++];
            if (s[j] == '.')
                dotCount++;
        }
        i = 0;
        j++;

        while (s[j] != '\0')
            host[i++] = s[j++];

        cout<<"\nNetwork ID is "<<network;
        cout<<"\nHost ID is "<<host;
   }
   else{
    cout<<"\nIn this Class, IP address is not divided into Network and Host ID\n";

   }

}
int main(){
   char s[50];
   cout<<"Enter the ip address: ";
   cin>>s;
   char a=classdefine(s);
   cout<<"Class "<<a<<"\n";
   iddefine(s,a);




}
