#include <stdio.h>
#include <string.h>
int main()
{
 	int i,j,genlen,datalen;
 	char data[100],gen[30],temp[30],quot[100],rem[30],gen1[30];
 	printf("Enter Data: ");
 	scanf("%s",data);
 	printf("Enter the generator: ");
 	scanf("%s",gen);
 	genlen=strlen(gen);
 	datalen=strlen(data);
 	strcpy(gen1,gen);
 	for(i=0;i<genlen-1;i++)
 	{
 		data[datalen+i]='0';
 	}
 	for(i=0;i<genlen;i++){
     temp[i]=data[i];
    }

 	for(i=0;i<datalen;i++)
 	{
 		quot[i]=temp[0];
 		if(quot[i]=='0'){
       for(j=0;j<genlen;j++){
          gen[j]='0';
       }
 		}

 		else{
       for(j=0;j<genlen;j++){
          gen[j]=gen1[j];
       }

     }

 		for(j=genlen-1;j>0;j--)
 		{
 			if(temp[j]==gen[j]){
         rem[j-1]='0';
       }

 			else{
         rem[j-1]='1';
       }

 		}
 		rem[genlen-1]=data[i+genlen];
 		strcpy(temp,rem);
 	}
 	strcpy(rem,temp);
 	printf("\nQuotient is ");
 	for(i=0;i<datalen;i++){
      	printf("%c",quot[i]);
   }

 	printf("\nRemainder is ");
 	for(i=0;i<genlen-1;i++){
      printf("%c",rem[i]);
   }

 	printf("\nFinal data is: ");
 	for(i=0;i<datalen;i++){
      printf("%c",data[i]);
   }

 	for(i=0;i<genlen-1;i++){
      printf("%c",rem[i]);
   }

	printf("\n");
	return 0;

 }

