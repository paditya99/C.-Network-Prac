#include<iostream>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
using namespace std;

void senderside(int r){
   if(r==0){
     cout<<"SENDER'S SIDE:\n  Timeout...Resend...No acknowledgement received\n";
     cout<<"  Frame is sent again...\n";
   }

}

void receiverside(int r){


   if(r==0){
    cout<<"\nRECEIVER'S SIDE:\n  DATA LOSS... No acknowledgement sent...";
   }
}



int main(){
   int n,i,data[5],j,r,a;
   cout<<"***STOP AND WAIT PROTOCOL***\n\n";
   cout<<"Enter the number of packets to be sent: ";
   cin>>n;
   for(i=0;i<n;i++){
     cout<<"Enter data "<<i<<" : ";
     cin>>data[i];
   }
    cout<<endl;
    for(j=0;j<n;j++)
    {
        cout<<"SENDER'S SIDE: \n"<<"Packet number "<<j+1<<" is sent... Data: "<<data[j];

        r=rand()%2;
        if(r==1){
            cout<<"\nRECEIVER'S SIDE:\n  Acknowledgement number "<<(j+2)<<" is sent\n";
        }

          else{
               receiverside(r);
               senderside(r);
               j--;

        }
    }
    cout<<"\nSTOP AND WAIT COMPLETES\n";


}
