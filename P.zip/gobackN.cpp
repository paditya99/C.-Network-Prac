#include<iostream>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
using namespace std;
int main(){
   int n,sent=0,ack,i;
   cout<<"***GO BACK N PROTOCOL***\n\n";
   cout<<"Enter the window size: ";
   cin>>n;
   while(1){
     for(i=0;i<n;i++){
       cout<<"\nSENDER'S SIDE:\nFrame "<<(sent+1)<<" has been transmitted.";
       cout<<"\nRECEIVER'S SIDE:\nAcknowledgement number "<<(sent+2)<<" has been sent.\n";
       sent++;
       if(sent==n)
       {
         break;
       }
     }
     ack=rand()%n+1;
     cout<<"\nNEGATIVE ACK received: "<<ack+1;
     if(ack==n){
       break;
     }
     else{
       sent=ack;
     }

   }
   return 0;
}
